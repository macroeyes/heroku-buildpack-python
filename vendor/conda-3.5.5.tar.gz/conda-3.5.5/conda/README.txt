
                      +---------+
                      |   cli   |
                      +---------+
                          |
                          |
             +---------------------------+
             |           plan            |
             +---------------------------+
              /   |     |      |      |
             /    |     |      |      |
      resolve   fetch   |      |   progressbar
      /  |  \           |      |
     /   |   \          |      |
  verlib |  utils    config  install
         |              |
         |              |
         |          (optional)
         |              |
         |              |
      pycosat          yaml
