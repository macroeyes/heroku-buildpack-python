import sys
from conda.cli import main

sys.exit(main())
